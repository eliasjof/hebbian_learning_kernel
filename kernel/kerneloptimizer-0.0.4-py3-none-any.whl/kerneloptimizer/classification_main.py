import argparse
import functools
import itertools
import logging
import numpy as np
import os
import pandas as pd

from kerneloptimizer.config.gridsearch_config import grid_params
from kerneloptimizer.functions import loss_functions
from kerneloptimizer.neural_nets.mlp.neural_svm import NeuralKernel
from scipy.optimize import minimize_scalar, fmin, minimize, Bounds
from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import accuracy_score, roc_auc_score
from sklearn.model_selection import (
    StratifiedKFold,
    GridSearchCV,
    cross_val_score
)
from sklearn.svm import SVC, LinearSVC
from sklearn.utils.testing import ignore_warnings

logging.basicConfig(
    format='%(asctime)s %(levelname)-8s %(message)s',
    level=logging.INFO,
    datefmt='%Y-%m-%d %H:%M:%S'
)


@ignore_warnings(category=ConvergenceWarning)
def main(args):

    filenames = os.listdir(args.input_path)
    filenames = [f for f in filenames if f.endswith('.csv')]

    model_types = [
        'rbf_cv_svm', 'rbf_sup_svm', 'rbf_unsup_svm', 'rbf_mmd_svm',
        'sigmoid_cv_svm', 'sigmoid_sup_svm', 'sigmoid_unsup_svm', 'sigmoid_mmd_svm',
        'mlp_cv_svm', 'mlp_sup_svm', 'mlp_unsup_svm', 'mlp_mmd_svm',
        'laplacian_cv_svm', 'laplacian_sup_svm', 'laplacian_unsup_svm', 'laplacian_mmd_svm'
    ]

    accuracies = {}
    aucs = {}
    for m in model_types:
        accuracies[m] = {
            'Basename': [],
            'Mean': [],
            'StdDev': []
        }

        aucs[m] = {
            'Basename': [],
            'Mean': [],
            'StdDev': []
        }


    for f in filenames:

        basename = f[:-4]
        logging.info('Running for dataset {}'.format(
            basename))

        X = pd.read_csv('{}/{}'.format(
            args.input_path, f))
        y = X.pop('Target')

        # Converting to NumPy
        X = X.to_numpy()
        y = y.to_numpy()


        # State variables
        split = 0

        acc_results = {}
        auc_results = {}
        for m in model_types:
            acc_results[m] = np.zeros(args.n_folds)
            auc_results[m] = np.zeros(args.n_folds)

        skf = StratifiedKFold(n_splits=args.n_folds, shuffle=True)
        for train_idx, test_idx in skf.split(X,y):

            logging.info('\tSplit number: {}'.format(split))

            # Splitting data

            X_train = X[train_idx]
            y_train = y[train_idx]

            X_test = X[test_idx]
            y_test = y[test_idx]

            print('Sigmoid test')
            fun = lambda gamma: loss_functions.supervised_sigmoid_loss(
                X_train, y_train, gamma)
            result = minimize_scalar(fun, bounds=(0.,np.inf))

            fun = lambda gamma: loss_functions.unsupervised_sigmoid_loss(
                X_train, gamma)
            fun = lambda gamma: np.tanh(gamma)
            result = minimize_scalar(fun, bounds=(0.,np.inf))

            ######## RBF Kernel with CV

            logging.info('\t\tEstimator: CV RBF Kernel')

            clf = SVC(kernel='rbf')

            # Grid Search with Cross Validation for baseline
            params = grid_params['rbf_svm']
            clf_cv = GridSearchCV(clf, params)

            clf_cv.fit(X_train, y_train)
            best_clf = clf_cv.best_estimator_

            predictions = best_clf.predict(X_test)
            prediction_scores = best_clf.decision_function(X_test)

            acc = accuracy_score(y_test, predictions)
            acc_results['rbf_cv_svm'][split] = acc

            auc = roc_auc_score(y_test, prediction_scores)
            auc_results['rbf_cv_svm'][split] = auc

            logging.info('\t\t\tAccuracy: {}'.format(acc))
            logging.info('\t\t\tAUC: {}'.format(auc))

            ######### RBF Kernel with Supervised loss function

            logging.info('\t\tEstimator: Supervised RBF Kernel')

            ## Finding Sigma

            ## Function to minimize
            fun = lambda sigma: loss_functions.supervised_rbf_loss(
                X_train, y_train, sigma)
            result = minimize_scalar(fun, bounds=(0.,np.inf))
            print(result.nit, result.x, result.fun)
            assert result.success

            best_sigma = result['x']
            best_gamma = 1. / (2. * (best_sigma ** 2.))

            clf = SVC(kernel='rbf', gamma=best_gamma)

            # Grid Search only C with Cross Validation
            params = grid_params['rbf_svm']
            params = {'C': params['C']}

            clf_cv = GridSearchCV(clf, params)

            clf_cv.fit(X_train, y_train)
            best_clf = clf_cv.best_estimator_

            predictions = best_clf.predict(X_test)
            prediction_scores = best_clf.decision_function(X_test)

            acc = accuracy_score(y_test, predictions)
            acc_results['rbf_sup_svm'][split] = acc

            auc = roc_auc_score(y_test, prediction_scores)
            auc_results['rbf_sup_svm'][split] = auc

            logging.info('\t\t\tAccuracy: {}'.format(acc))
            logging.info('\t\t\tAUC: {}'.format(auc))

            ######### RBF Kernel with MMD loss function

            logging.info('\t\tEstimator: MMD RBF Kernel')

            ## Finding Sigma

            ## Function to minimize
            fun = lambda sigma: loss_functions.mmd_rbf_loss(
                X_train, y_train, sigma)
            result = minimize_scalar(fun, bounds=(0.,np.inf))
            print(result.nit, result.x, result.fun)
            assert result.success

            best_sigma = result['x']
            best_gamma = 1. / (2. * (best_sigma ** 2.))

            clf = SVC(kernel='rbf', gamma=best_gamma)

            # Grid Search only C with Cross Validation
            params = grid_params['rbf_svm']
            params = {'C': params['C']}

            clf_cv = GridSearchCV(clf, params)

            clf_cv.fit(X_train, y_train)
            best_clf = clf_cv.best_estimator_

            predictions = best_clf.predict(X_test)
            prediction_scores = best_clf.decision_function(X_test)

            acc = accuracy_score(y_test, predictions)
            acc_results['rbf_mmd_svm'][split] = acc

            auc = roc_auc_score(y_test, prediction_scores)
            auc_results['rbf_mmd_svm'][split] = auc

            logging.info('\t\t\tAccuracy: {}'.format(acc))
            logging.info('\t\t\tAUC: {}'.format(auc))

            ######### RBF Kernel with Unsupervised loss function

            logging.info('\t\tEstimator: Unsupervised RBF Kernel')

            # Finding Sigma

            # Function to minimize
            fun = lambda sigma: loss_functions.unsupervised_rbf_loss(
                X_train, sigma)
            result = minimize_scalar(fun, bounds=(0.,np.inf))
            print(result.nit, result.x, result.fun)
            assert result.success

            best_sigma = result['x']
            best_gamma = 1. / (2. * (best_sigma ** 2.))

            clf = SVC(kernel='rbf', gamma=best_gamma)

            # Grid Search only C with Cross Validation
            params = grid_params['rbf_svm']
            params = {'C': params['C']}

            clf_cv = GridSearchCV(clf, params)

            clf_cv.fit(X_train, y_train)
            best_clf = clf_cv.best_estimator_

            predictions = best_clf.predict(X_test)
            prediction_scores = best_clf.decision_function(X_test)

            acc = accuracy_score(y_test, predictions)
            acc_results['rbf_unsup_svm'][split] = acc

            auc = roc_auc_score(y_test, prediction_scores)
            auc_results['rbf_unsup_svm'][split] = auc

            logging.info('\t\t\tAccuracy: {}'.format(acc))
            logging.info('\t\t\tAUC: {}'.format(auc))

            ######### Laplacian Kernel with CV

            logging.info('\t\tEstimator: CV Laplacian Kernel')

            # Grid Search with Cross Validation for baseline
            params = grid_params['laplacian_svm']

            param_combination = []

            best_score = -1.
            best_comb = 0
            i = 0
            best_sigma = 1.
            best_C = 1.
            for C, sigma in itertools.product(*params.values()):

                sigma_laplacian_kernel = functools.partial(
                    loss_functions.laplacian_kernel,
                    sigma=sigma
                )

                clf = SVC(kernel=loss_functions.laplacian_kernel,
                         C=C,max_iter=30000)

                scores = cross_val_score(clf, X_train, y_train)
                avg_score = scores.mean()
                param_combination.append((C,sigma,avg_score))
                if avg_score > best_score:
                    best_score = avg_score
                    best_C = C
                    best_sigma = sigma
                    best_idx = i

                i += 1

            sigma_laplacian_kernel = functools.partial(
                loss_functions.laplacian_kernel,
                sigma=best_sigma
            )

            best_clf = SVC(kernel=loss_functions.laplacian_kernel,
                     C=best_C,max_iter=30000)
            best_clf.fit(X_train, y_train)

            predictions = best_clf.predict(X_test)
            prediction_scores = best_clf.decision_function(X_test)

            acc = accuracy_score(y_test, predictions)
            acc_results['laplacian_cv_svm'][split] = acc

            auc = roc_auc_score(y_test, prediction_scores)
            auc_results['laplacian_cv_svm'][split] = auc

            logging.info('\t\t\tAccuracy: {}'.format(acc))
            logging.info('\t\t\tAUC: {}'.format(auc))

            ######### Laplacian Kernel with Supervised loss function

            logging.info('\t\tEstimator: Supervised Laplacian Kernel')

            # Finding Sigma

            # Function to minimize
            fun = lambda sigma: loss_functions.supervised_laplacian_loss(
                X_train, y_train, sigma)
            result = minimize_scalar(fun, bounds=(0.,np.inf))
            print(result.nit, result.x, result.fun)
            assert result.success

            best_sigma = result['x']
            best_laplacian_kernel = functools.partial(
                loss_functions.laplacian_kernel,
                sigma=best_sigma
            )

            clf = SVC(kernel=best_laplacian_kernel,max_iter=30000)

            # Grid Search only C with Cross Validation
            params = grid_params['laplacian_svm']
            params = {'C': params['C']}

            clf_cv = GridSearchCV(clf, params)

            clf_cv.fit(X_train, y_train)
            best_clf = clf_cv.best_estimator_

            predictions = best_clf.predict(X_test)
            prediction_scores = best_clf.decision_function(X_test)

            acc = accuracy_score(y_test, predictions)
            acc_results['laplacian_sup_svm'][split] = acc

            auc = roc_auc_score(y_test, prediction_scores)
            auc_results['laplacian_sup_svm'][split] = auc

            logging.info('\t\t\tAccuracy: {}'.format(acc))
            logging.info('\t\t\tAUC: {}'.format(auc))

            ######### Laplacian Kernel with MMD loss function

            logging.info('\t\tEstimator: MMD Laplacian Kernel')

            # Finding Sigma

            # Function to minimize
            fun = lambda sigma: loss_functions.mmd_laplacian_loss(
                X_train, y_train, sigma)
            result = minimize_scalar(fun, bounds=(0.,np.inf))
            print(result.nit, result.x, result.fun)
            assert result.success

            best_sigma = result['x']
            best_laplacian_kernel = functools.partial(
                loss_functions.laplacian_kernel,
                sigma=best_sigma
            )

            clf = SVC(kernel=best_laplacian_kernel,max_iter=30000)

            # Grid Search only C with Cross Validation
            params = grid_params['laplacian_svm']
            params = {'C': params['C']}

            clf_cv = GridSearchCV(clf, params)

            clf_cv.fit(X_train, y_train)
            best_clf = clf_cv.best_estimator_

            predictions = best_clf.predict(X_test)
            prediction_scores = best_clf.decision_function(X_test)

            acc = accuracy_score(y_test, predictions)
            acc_results['laplacian_mmd_svm'][split] = acc

            auc = roc_auc_score(y_test, prediction_scores)
            auc_results['laplacian_mmd_svm'][split] = auc

            logging.info('\t\t\tAccuracy: {}'.format(acc))
            logging.info('\t\t\tAUC: {}'.format(auc))

            ######### Laplacian Kernel with Unsupervised loss function

            logging.info('\t\tEstimator: Unsupervised Laplacian Kernel')

            # Finding Sigma

            # Function to minimize
            fun = lambda sigma: loss_functions.unsupervised_laplacian_loss(
                X_train, sigma)
            result = minimize_scalar(fun, bounds=(0.,np.inf))
            print(result.nit, result.x, result.fun)
            assert result.success

            best_sigma = result['x']
            best_laplacian_kernel = functools.partial(
                loss_functions.laplacian_kernel,
                sigma=best_sigma
            )

            clf = SVC(kernel=best_laplacian_kernel,max_iter=30000)

            # Grid Search only C with Cross Validation
            params = grid_params['laplacian_svm']
            params = {'C': params['C']}

            clf_cv = GridSearchCV(clf, params)

            clf_cv.fit(X_train, y_train)
            best_clf = clf_cv.best_estimator_

            predictions = best_clf.predict(X_test)
            prediction_scores = best_clf.decision_function(X_test)

            acc = accuracy_score(y_test, predictions)
            acc_results['laplacian_unsup_svm'][split] = acc

            auc = roc_auc_score(y_test, prediction_scores)
            auc_results['laplacian_unsup_svm'][split] = auc

            logging.info('\t\t\tAccuracy: {}'.format(acc))
            logging.info('\t\t\tAUC: {}'.format(auc))

            ######## Sigmoid Kernel with CV

            logging.info('\t\tEstimator: CV Sigmoid Kernel')

            clf = SVC(kernel='sigmoid',max_iter=30000)

            # Grid Search with Cross Validation for baseline
            params = grid_params['sigmoid_svm']
            clf_cv = GridSearchCV(clf, params)

            clf_cv.fit(X_train, y_train)
            best_clf = clf_cv.best_estimator_

            predictions = best_clf.predict(X_test)
            prediction_scores = best_clf.decision_function(X_test)

            acc = accuracy_score(y_test, predictions)
            acc_results['sigmoid_cv_svm'][split] = acc

            auc = roc_auc_score(y_test, prediction_scores)
            auc_results['sigmoid_cv_svm'][split] = auc

            logging.info('\t\t\tAccuracy: {}'.format(acc))
            logging.info('\t\t\tAUC: {}'.format(auc))

            ######## Sigmoid Kernel with Supervised loss function

            logging.info('\t\tEstimator: Supervised Sigmoid Kernel')

            # Finding Gamma

            # Function to minimize
            #fun = lambda gamma: loss_functions.supervised_sigmoid_loss(
            #    X_train, y_train, gamma)
            #result = minimize_scalar(fun, bounds=(0.,np.inf))
            #print(result.nit, result.x, result.fun)
            #assert result.success
            fun = lambda params: loss_functions.supervised_sigmoid_loss(
                X_train, y_train, params)
            #result = fmin(fun, [.1,.1], maxiter=500)
            bounds = Bounds([0.0,0.0], [np.inf, np.inf])
            result = minimize(fun, [.1,.1], bounds=bounds, options={'maxiter': 500})
            print(result)

            #best_gamma = result['x']
            #from IPython import embed
            #embed()
            best_gamma, best_b = result.x

            clf = SVC(kernel='sigmoid', gamma=best_gamma,coef0=best_b, max_iter=30000)

            # Grid Search only C with Cross Validation
            params = grid_params['sigmoid_svm']
            params = {'C': params['C']}

            clf_cv = GridSearchCV(clf, params)

            clf_cv.fit(X_train, y_train)
            best_clf = clf_cv.best_estimator_

            predictions = best_clf.predict(X_test)
            prediction_scores = best_clf.decision_function(X_test)

            acc = accuracy_score(y_test, predictions)
            acc_results['sigmoid_sup_svm'][split] = acc

            auc = roc_auc_score(y_test, prediction_scores)
            auc_results['sigmoid_sup_svm'][split] = auc

            logging.info('\t\t\tAccuracy: {}'.format(acc))
            logging.info('\t\t\tAUC: {}'.format(auc))

            ######## Sigmoid Kernel with MMD loss function

            logging.info('\t\tEstimator: MMD Sigmoid Kernel')

            # Finding Gamma

            # Function to minimize
            #fun = lambda gamma: loss_functions.supervised_sigmoid_loss(
            #    X_train, y_train, gamma)
            #result = minimize_scalar(fun, bounds=(0.,np.inf))
            #print(result.nit, result.x, result.fun)
            #assert result.success
            fun = lambda params: loss_functions.mmd_sigmoid_loss(
                X_train, y_train, params)
            #result = fmin(fun, [.1,.1], maxiter=500)
            bounds = Bounds([0.0,0.0], [np.inf, np.inf])
            result = minimize(fun, [.1,.1], bounds=bounds, options={'maxiter': 500})
            print(result)

            #best_gamma = result['x']
            #from IPython import embed
            #embed()
            best_gamma, best_b = result.x

            clf = SVC(kernel='sigmoid', gamma=best_gamma,coef0=best_b, max_iter=30000)

            # Grid Search only C with Cross Validation
            params = grid_params['sigmoid_svm']
            params = {'C': params['C']}

            clf_cv = GridSearchCV(clf, params)

            clf_cv.fit(X_train, y_train)
            best_clf = clf_cv.best_estimator_

            predictions = best_clf.predict(X_test)
            prediction_scores = best_clf.decision_function(X_test)

            acc = accuracy_score(y_test, predictions)
            acc_results['sigmoid_mmd_svm'][split] = acc

            auc = roc_auc_score(y_test, prediction_scores)
            auc_results['sigmoid_mmd_svm'][split] = auc

            logging.info('\t\t\tAccuracy: {}'.format(acc))
            logging.info('\t\t\tAUC: {}'.format(auc))

            ######## Sigmoid Kernel with Unsupervised loss function

            logging.info('\t\tEstimator: Unsupervised Sigmoid Kernel')

            # Finding Gamma

            # Function to minimize
            fun = lambda params: loss_functions.unsupervised_sigmoid_loss(
                X_train, params)
            #result = fmin(fun, [.1,.1], maxiter=500)
            bounds = Bounds([0.0,0.0], [np.inf, np.inf])
            result = minimize(fun, [.1,.1], bounds=bounds, options={'maxiter': 500})
            print(result)
            #print(result.iter, result.x, result.fun)
            #assert result.success

            #best_gamma = result['x']
            best_gamma, best_b = result.x

            clf = SVC(kernel='sigmoid', gamma=best_gamma, coef0=best_b,max_iter=30000)

            # Grid Search only C with Cross Validation
            params = grid_params['sigmoid_svm']
            params = {'C': params['C']}

            clf_cv = GridSearchCV(clf, params)

            clf_cv.fit(X_train, y_train)
            best_clf = clf_cv.best_estimator_

            predictions = best_clf.predict(X_test)
            prediction_scores = best_clf.decision_function(X_test)

            acc = accuracy_score(y_test, predictions)
            acc_results['sigmoid_unsup_svm'][split] = acc

            auc = roc_auc_score(y_test, prediction_scores)
            auc_results['sigmoid_unsup_svm'][split] = auc

            logging.info('\t\t\tAccuracy: {}'.format(acc))
            logging.info('\t\t\tAUC: {}'.format(auc))

            ######## Neural Kernel with Supervised loss function

            logging.info('\t\tEstimator: Supervised Neural Kernel')

            # Fitting network
            logging.info('\t\t\t\tFitting network')

            d = X_train.shape[1]
            supervised_mlp = NeuralKernel(d)

            supervised_mlp.fit(X_train, y_train, method='supervised')
            X_train_transf = supervised_mlp.transform(X_train)
            assert np.isnan(X_train_transf).sum() == 0

            clf = LinearSVC(max_iter=30000)

            # Grid Search only C with Cross Validation
            logging.info('\t\t\t\tGrid search')
            params = grid_params['rbf_svm']
            params = {'C': params['C']}

            clf_cv = GridSearchCV(clf, params)

            clf_cv.fit(X_train_transf, y_train)
            logging.info('\t\t\t\tDone!')
            best_clf = clf_cv.best_estimator_

            X_test_transf = supervised_mlp.transform(X_test)
            assert np.isnan(X_test_transf).sum() == 0
            predictions = best_clf.predict(X_test_transf)
            prediction_scores = best_clf.decision_function(X_test_transf)

            acc = accuracy_score(y_test, predictions)
            acc_results['mlp_sup_svm'][split] = acc

            auc = roc_auc_score(y_test, prediction_scores)
            auc_results['mlp_sup_svm'][split] = auc

            logging.info('\t\t\tAccuracy: {}'.format(acc))
            logging.info('\t\t\tAUC: {}'.format(auc))

            ######## Neural Kernel with MMD loss function

            logging.info('\t\tEstimator: MMD Neural Kernel')

            # Fitting network
            logging.info('\t\t\t\tFitting network')

            d = X_train.shape[1]
            supervised_mlp = NeuralKernel(d)

            supervised_mlp.fit(X_train, y_train, method='mmd')
            X_train_transf = supervised_mlp.transform(X_train)
            assert np.isnan(X_train_transf).sum() == 0

            clf = LinearSVC(max_iter=30000)

            # Grid Search only C with Cross Validation
            logging.info('\t\t\t\tGrid search')
            params = grid_params['rbf_svm']
            params = {'C': params['C']}

            clf_cv = GridSearchCV(clf, params)

            clf_cv.fit(X_train_transf, y_train)
            logging.info('\t\t\t\tDone!')
            best_clf = clf_cv.best_estimator_

            X_test_transf = supervised_mlp.transform(X_test)
            assert np.isnan(X_test_transf).sum() == 0
            predictions = best_clf.predict(X_test_transf)
            prediction_scores = best_clf.decision_function(X_test_transf)

            acc = accuracy_score(y_test, predictions)
            acc_results['mlp_mmd_svm'][split] = acc

            auc = roc_auc_score(y_test, prediction_scores)
            auc_results['mlp_mmd_svm'][split] = auc

            logging.info('\t\t\tAccuracy: {}'.format(acc))
            logging.info('\t\t\tAUC: {}'.format(auc))

            ######### Neural Kernel with Unsupervised loss function

            logging.info('\t\tEstimator: Unsupervised Neural Kernel')

            # Fitting network

            logging.info('\t\t\t\tFitting network')
            d = X_train.shape[1]
            unsupervised_mlp = NeuralKernel(d)

            unsupervised_mlp.fit(X_train, y_train, supervised=False)
            X_train_transf = unsupervised_mlp.transform(X_train)
            assert np.isnan(X_train_transf).sum() == 0

            clf = LinearSVC(max_iter=30000)

            # Grid Search only C with Cross Validation
            logging.info('\t\t\t\tGrid search')
            params = grid_params['rbf_svm']
            params = {'C': params['C']}

            clf_cv = GridSearchCV(clf, params)

            clf_cv.fit(X_train_transf, y_train)
            logging.info('\t\t\t\tDone!')
            best_clf = clf_cv.best_estimator_

            X_test_transf = unsupervised_mlp.transform(X_test)
            assert np.isnan(X_test_transf).sum() == 0
            predictions = best_clf.predict(X_test_transf)
            prediction_scores = best_clf.decision_function(X_test_transf)

            acc = accuracy_score(y_test, predictions)
            acc_results['mlp_unsup_svm'][split] = acc

            auc = roc_auc_score(y_test, prediction_scores)
            auc_results['mlp_unsup_svm'][split] = auc

            logging.info('\t\t\tAccuracy: {}'.format(acc))
            logging.info('\t\t\tAUC: {}'.format(auc))

            split += 1

        # Aggregating results
        agg_acc = dict([
            (key, {
                'mean': v.mean(),
                'std': v.std()
            }) for key, v in acc_results.items()
        ])

        agg_auc = dict([
            (key, {
                'mean': v.mean(),
                'std': v.std()
            }) for key, v in auc_results.items()
        ])

        for k in agg_acc.keys():
            accuracies[k]['Basename'].append(basename)
            accuracies[k]['Mean'].append(agg_acc[k]['mean'])
            accuracies[k]['StdDev'].append(agg_acc[k]['std'])

            aucs[k]['Basename'].append(basename)
            aucs[k]['Mean'].append(agg_auc[k]['mean'])
            aucs[k]['StdDev'].append(agg_auc[k]['std'])

        logging.info('Aggregate results:')
        logging.info('\tAccuracy:')
        for model, result in agg_acc.items():
            logging.info('\t\t{}: {} +- {}'.format(
                model, round(result['mean'],3), round(result['std'],3)
            ))

        logging.info('\tAUC:')
        for model, result in agg_auc.items():
            logging.info('\t\t{}: {} +- {}'.format(
                model, round(result['mean'],3), round(result['std'],3)
            ))

    # Saving csvs

    for k in accuracies.keys():
        df = pd.DataFrame(accuracies[k])
        df.to_csv('{}/classification/accuracy/{}.csv'.format(
            args.output_path, k))

        df = pd.DataFrame(aucs[k])
        df.to_csv('{}/classification/auc/{}.csv'.format(
            args.output_path, k))



if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '-f', '--n_folds', required=True, type=int)
    parser.add_argument(
        '-i', '--input_path', required=True, type=str)
    parser.add_argument(
        '-o', '--output_path', required=True, type=str)

    args = parser.parse_args()
    main(args)
