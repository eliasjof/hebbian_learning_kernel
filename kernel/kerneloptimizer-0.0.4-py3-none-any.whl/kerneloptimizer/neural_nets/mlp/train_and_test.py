import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import os
import sys
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.autograd as autograd
import torch.optim as optim

from sklearn.svm import SVC
from sklearn.metrics import accuracy_score


def dotProductLoss(X, normalize=False):

    if normalize:
        X = F.normalize(X, dim=1)

    gram_mat = torch.mm(X, X.t())
    means = torch.mean(gram_mat, dim=1)
    loss = means.var()

    return -1 * loss


def supervisedDotProductLoss(X, y, normalize=False):

    if normalize:
        X = F.normalize(X, dim=1)

    gram_mat = torch.mm(X, X.t())
    which_c0 = np.where(y == 0)[0]
    which_c1 = np.where(y == 1)[0]

    sim_to_c0 = torch.mean(gram_mat[:, which_c0], dim=1)
    sim_to_c1 = torch.mean(gram_mat[:, which_c1], dim=1)

    sim_c0_c0 = torch.mean(sim_to_c0[which_c0])
    sim_c0_c1 = torch.mean(sim_to_c1[which_c0])
    sim_c1_c0 = torch.mean(sim_to_c0[which_c1])
    sim_c1_c1 = torch.mean(sim_to_c1[which_c1])

    loss = (sim_c0_c0 - sim_c1_c0) ** 2 + (sim_c1_c1 - sim_c0_c1) ** 2
    return -1 * loss


class MLP(torch.nn.Module):

    def __init__(self, input_dim, hidden_dim, output_dim):
        super(MLP, self).__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        self.layer1 = torch.nn.Linear(self.input_dim, self.hidden_dim)
        self.layer1.weight.data.uniform_(-1.0, 1.0)
        self.tanh = torch.nn.Tanh()
        self.layer2 = torch.nn.Linear(self.hidden_dim, self.output_dim)
        self.layer2.weight.data.uniform_(-1.0, 1.0)
        self.sigmoid = torch.nn.Sigmoid()
        self.relu = torch.nn.ReLU()
        self.tanh = torch.nn.Tanh()

    def forward(self, x):
        x = self.layer1(x)
        x = self.tanh(x)
        x = self.layer2(x)
        output = self.sigmoid(x) / np.sqrt(self.output_dim)
        output = F.normalize(output, dim=1)

        return output


def train_and_transform(
    X, y,
    X_test,
    supervised=True,
    input_dim=2, hidden_dim=10, output_dim=20, # NNs should be wide to untangle latent factors
    n_epochs=10000
):
    print(X.shape)
    print(X_test.shape)

    X_tensor = torch.tensor(X, dtype=torch.float)
    X_test_tensor = torch.tensor(X_test, dtype=torch.float)

    print(X_tensor.shape)
    print(X_test_tensor.shape)

    model = MLP(
        input_dim,
        hidden_dim,
        output_dim
    )

    optimizer = torch.optim.RMSprop(model.parameters())

    model.train()
    n_epochs = n_epochs
    for epoch in range(n_epochs):
        optimizer.zero_grad()
        X_out = model(X_tensor)

        if supervised:
            loss = supervisedDotProductLoss(X_out, y, normalize=False)
        else:
            loss = dotProductLoss(X_out, normalize=False)

        if epoch % 100 == 0:
            print('Epoch {}: Loss: {}'.format(epoch, loss.item()))

        loss.backward()
        optimizer.step()

    model.eval()
    x_final = model(X_tensor)
    x_test_final = model(X_test_tensor)

    x_final_np = x_final.detach().numpy()
    x_test_final_np = x_test_final.detach().numpy()

    return {
        'train': x_final_np,
        'test': x_test_final_np
    }



def return_tuple():
    return 1, 2, 3

def return_list():
    return [1,2,3]

def return_dict():
    return {
        'a': 1,
        'b': 2,
        'c': 3
    }
